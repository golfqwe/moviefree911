<?
session_start();
include "../inc/config.inc.php";
if(!isset($_SESSION['admin_login'])) {
echo "<meta http-equiv='refresh' content='0;url=index.php'>" ; 
exit() ;
}
$id=$_GET['id'];
$sp="SELECT name, email, pass FROM `member` WHERE type=2 AND id='$id'";
$rep=mysqli_query($con_db, $sp) or die("ERROR $sp");
$rp=mysqli_fetch_row($rep);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Admin Panel : ระบบจัดการข้อมูลเว็บไซต์</title>
<link rel='stylesheet' type='text/css' href='styles.css' />
<link rel="stylesheet" href="https://<?=$titler[3];?>/css/bootstrap.min.css">
<style type="text/css">
<!--
body {
	margin-top: 0px;
	margin-bottom: 0px;
	background-color: #999999;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
}
a:active {
	text-decoration: none;
}
.style4 {font-size: small; font-weight: bold; }
-->
</style></head>

<body>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="220" align="center" valign="top" bgcolor="#222222"><? include "menu.php"; ?></td>
    <td width="760" align="center" valign="top" bgcolor="#FFFFFF"><table width="750" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td height="25" style="border-bottom:2px solid #FF0000;"><table width="750" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td width="500"><table width="500" border="0" align="center" cellpadding="0" cellspacing="0">
                <tr>
                  <td align="left" id="font-main" style="font-weight:bold; color:#333333;">Admin Panel : ระบบจัดการข้อมูลเว็บไซต์ </td>
                </tr>
            </table></td>
            <td width="250"><table width="250" border="0" align="center" cellpadding="0" cellspacing="0">
                <tr>
                  <td width="175" align="right"><img src="img/Power-Shutdown.png" width="16" height="16" /></td>
                  <td width="75" align="right" id="font-main"><a href="logout.php" style="font-weight:bold; color:#333333;">ออกจากระบบ</a></td>
                </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><table width="750" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td height="25" align="left" id="font-main" style="font-weight:bold; color:#333333;"><a href="mod.php">จัดการข้อมูลผู้ช่วยแอดมิน</a> <img src="images/arrow.gif" width="7" height="11" /> แก้ไขข้อมูลผู้ช่วยแอดมิน</td>
            </tr>
            <tr>
              <td><table width="750" border="0" align="center" cellpadding="0" cellspacing="0">
                <tr>
                  <td><form action="p-edit-mod.php" method="post" enctype="multipart/form-data" name ="checkForm" id="checkForm" onsubmit="return check1()">
                      <table width="100%" height="10" border="0" align="center" cellpadding="0" cellspacing="0">
                        <tr>
                          <td></td>
                        </tr>
                      </table>
                    <table width="600" border="0" align="center" cellpadding="0" cellspacing="0">
                        <tr>
                          <td width="150" align="right" id="font-main">ชื่อที่ใช้เรียก/นามแฝง</td>
                          <td width="10">&nbsp;</td>
                          <td width="440">
						  <input name="name" type="text" id="name" value="<?=$rp[0];?>" />
						  <input type="hidden" name="id" id="id" value="<?=$id;?>" />						  </td>
                        </tr>
                        <tr>
                          <td width="150" align="right" id="font-main">อีเมล์</td>
                          <td width="10">&nbsp;</td>
                          <td width="440"><input name="email" type="text" id="email" value="<?=$rp[1];?>" /></td>
                        </tr>
                        <tr>
                          <td align="right" id="font-main">รหัสผ่าน</td>
                          <td>&nbsp;</td>
                          <td width="440" id="font-main" style="color:#FF0000;"><input name="pass" type="password" id="pass" value="<?=$rp[2];?>" /> <?=$rp[2];?></td>
                        </tr>
                        
                        <tr>
                          <td width="150">&nbsp;</td>
                          <td width="10">&nbsp;</td>
                          <td width="440"><label>
                            <input type="submit" name="Submit" value="บันทึกข้อมูล" />
                          </label></td>
                        </tr>
                      </table>
<script language="JavaScript" type="text/javascript">

function check1() {
if(document.checkForm.name.value=="") {
alert("กรุณากรอกชื่อที่ใช้เรียก/นามแฝงด้วยนะครับ") ;
document.checkForm.name.focus() ;
return false ;
}else if(document.checkForm.email.value=="") {
alert("กรุณากรอกอีเมล์ด้วยนะครับ") ;
document.checkForm.email.focus() ;
return false ;
}else if(document.checkForm.pass.value=="") {
alert("กรุณากรอกรหัสผ่านด้วยนะครับ") ;
document.checkForm.pass.focus() ;
return false ;
}
else 
return true ;
}
                      </script>
                  </form></td>
                </tr>
                <tr>
                  <td><table width="100%" height="10" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td></td>
                      </tr>
                    </table><center style="color: red;">กรุณาตรวจสอบให้แน่ใจก่อนลบ User ผู้ช่วย เพราะจำทำให้หนังทั้งหมดถูกลบไปด้วย  </center>
                      <table width="750" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#E9E9E6">
                        <tr>
                          <td width="75" height="30" align="center" valign="middle" bgcolor="#EFEFED" id="font-main" style="font-weight:bold;">ลำดับที่</td>
                          <td width="200" height="30" align="center" valign="middle" bgcolor="#EFEFED" id="font-main" style="font-weight:bold;">ชื่อที่ใช้เรียก/นามแฝง</td>
                          <td width="200" height="30" align="center" valign="middle" bgcolor="#EFEFED" id="font-main" style="font-weight:bold;">อีเมล์</td>
                          <td width="150" height="30" align="center" valign="middle" bgcolor="#EFEFED" id="font-main" style="font-weight:bold;">รหัสผ่าน</td>
                          <td width="125" align="center" valign="middle" bgcolor="#EFEFED" id="font-main" style="font-weight:bold;">การกระทำ</td>
                        </tr>
<?
$s="SELECT id, name, email, pass FROM `member` WHERE type=2";
$re=mysqli_query($con_db, $s) or die("ERROR $s");
$x=1;
while($r=mysqli_fetch_row($re)){
?>
                        <tr>
                          <td width="75" height="25" align="center" valign="middle" id="font-main"><?=$x;?></td>
                          <td width="200" height="25" align="center" valign="middle" id="font-main"><?=$r[1];?></td>
                          <td width="200" height="25" align="center" valign="middle" id="font-main"><?=$r[2];?></td>
                          <td width="150" height="25" align="center" valign="middle" id="font-main"><?=$r[3];?></td>
                          <td width="125" align="center" valign="middle"><select name="manage" id="manage" onchange="window.open(this.options[this.selectedIndex].value,'_self')">
                              <option value="" selected="selected">- เลือก -</option>
                              <option value="edit-mod.php?id=<?=$r[0];?>">แก้ไขข้อมูล</option>
                              <option value="list-mod-movie.php?id=<?=$r[0];?>">รายการโพสต์หนัง</option>
                              <option value="del-mod.php?id=<?=$r[0];?>">ลบข้อมูล</option>
                            </select>
                          </td>
                        </tr>
                        <? $x++;} ?>
                      </table></td>
                </tr>
              </table></td>
            </tr>
          </table></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
