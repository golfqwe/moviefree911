<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>.:: ระบบจัดการข้อมูลเว็บไซต์ ::.</title>
<style type="text/css">

<!--
body {
	background-color: #EBEBEB;
}
-->
</style></head>

<body>
<table width="450" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="100">&nbsp;</td>
  </tr>
  <tr>
    <td><table width="450" border="0" align="center" cellpadding="0" cellspacing="2" bgcolor="#CCCCCC">
      <tr>
        <td height="32" background="images/bg-menu.jpg"><font size="3">&nbsp;&nbsp;ระบบจัดการข้อมูลเว็บไซต์</font></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF"><form id="form1" name="form1" method="post" action="login.php">
          <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td height="5"></td>
            </tr>
          </table>
          <table width="430" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td align="left"><font size="3">Email</font></td>
            </tr>
            <tr>
              <td align="left"><input name="email" type="text" class="input" id="email" onblur="if(this.value==''){this.value='Email';}" onclick="if(this.value=='Email'){this.value='';}" value="Email" style="width:420px;"/></td>
            </tr>
            <tr>
              <td align="left"><font size="3">Password</font></td>
            </tr>
            <tr>
              <td align="left"><input name="pass" type="password" class="input" id="pass" onblur="if(this.value==''){this.value='Password'; }" onclick="if(this.value=='Password'){this.value='';}" value="Password" style="width:420px;"/></td>
            </tr>
            <tr>
              <td align="right"><input type="submit" name="Submit" value="เข้าสู่ระบบ" /></td>
            </tr>
          </table>
                <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                  <tr>
                    <td height="5"></td>
                  </tr>
                </table>
        </form>
        </td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
